#!/bin/bash
echo "启动游戏运维管理系统..."
node server.js 